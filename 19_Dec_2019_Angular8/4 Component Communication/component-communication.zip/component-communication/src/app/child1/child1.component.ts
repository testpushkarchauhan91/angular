import { Component, OnInit } from '@angular/core';
import { Input } from '@angular/core';
import { Output } from '@angular/core';
import { EventEmitter } from '@angular/core';

@Component({
  selector: 'app-child1',
  templateUrl: './child1.component.html',
  styleUrls: ['./child1.component.css']
})
export class Child1Component implements OnInit {
  @Input()
  parentName: string;

  @Input()
  stdParentNames: Array<string>; // retrive Parent Name Values in this array(stdParentNames) from Parent(stdName)
  
  messageInChild: string = "This is a child component Message";// retrive Child string in Parent
  greetingMessage: string;
  sizeOfArrayInChild: number;
  age:number = 21;

  constructor() { }

  ngOnInit() {
    
  }

  numberOfRecordsInArray(): number {
    this.sizeOfArrayInChild = this.stdParentNames.length;
    return this.sizeOfArrayInChild;
  }

  greet(): string {
   // return "Welcome";
    return  this.greetingMessage = "Hello World!!";
  }
  
  /*
   greet(): void {
     this.greetingMessage = "Hello World!!";
   }
   */
   
   // Child to Parent Using EventEmitter
   // Using EventEmitter
   // Value which you want to pass from C to P define it in <>
   // like in this case using age which is number
 
    @Output()
    eventRef = new EventEmitter<number>();
    
    // take value from text field and emit
    passValue(age){
      console.log("method called..");
      this.eventRef.emit(age);
    }
}
