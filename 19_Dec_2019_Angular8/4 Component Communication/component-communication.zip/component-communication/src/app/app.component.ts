import { Component } from '@angular/core';
import { ViewChild } from '@angular/core';
import { Child1Component } from './child1/child1.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'component-communication';
  name: string = "Ajay Kumar"; // Declaring a variable in parent and using it in component
  
  /* Only one String :  static*/
  // stdName: string; // Using Dynamic Values generating by Parent and child will use it to display
  
  /* Multiple Names :  dynamic*/
  stdName: Array<string> = new Array();

// Access Every Property of Child in Parent
//@ViewChild(Child1Component)       // used in Angular 7
  @ViewChild(Child1Component, null) // used in Angular 8 
  childRef: Child1Component;
  messageFromChild:string;
  sizeOfArrayInParent:number;
  
  ngOnInit(){
    this.messageFromChild = this.childRef.messageInChild;
//    this.sizeOfArrayInParent = this.childRef.numberOfRecordsInArray();
  }

  addNames(stdName: string) {
    // this.stdName = stdName; // single value
    this.stdName.push(stdName);
    this.sizeOfArrayInParent = this.childRef.numberOfRecordsInArray();
  }  
  
  childAge:number;
  
}
