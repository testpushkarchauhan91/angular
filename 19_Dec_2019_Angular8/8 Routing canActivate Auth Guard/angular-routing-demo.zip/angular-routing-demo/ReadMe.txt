http://localhost:4200/
http://localhost:4200/aboutus
http://localhost:4200/contactus
http://localhost:4200/home ==> will not allow to access directly
http://localhost:4200/login