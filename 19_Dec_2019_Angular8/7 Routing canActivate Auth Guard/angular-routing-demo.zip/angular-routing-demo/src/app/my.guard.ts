import { CanActivate } from '@angular/router';
// This class helps us to validate JWt Tokens
export class MyGuard implements CanActivate {
	canActivate() {
		console.log("I came here!");
		return true;
	}
}
// This is Auth Guard