import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';

@Injectable({
  providedIn: 'root' // provider:[EmployeeService]
})
export class EmployeeService {

  constructor(private http:HttpClient) { }
  
  checkUser(empId:number):Observable<any>{
    return this.http.get("http://dummy.restapiexample.com/api/v1/employee/"+empId,{responseType:"json"});
  }
}
