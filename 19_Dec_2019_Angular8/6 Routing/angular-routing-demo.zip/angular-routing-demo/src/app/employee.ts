export class Employee {
	constructor(public id: number,
		public employee_name: string,
		public employee_salary: number,
		public employee_age: number){}
}