import { Component, OnInit } from '@angular/core';
import { Router }from '@angular/router';
import { Employee } from '../employee';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  employees: Array<Employee>;
  constructor(private router: Router) {
    this.employees = new Array();
    let emp1 = new Employee(1, "ravi", 12000, 23);
    let emp2 = new Employee(2, "ajay", 1600, 22);
    let emp3 = new Employee(3, "ramesh", 14000, 23);
    let emp4 = new Employee(4, "seeta", 18000, 43);
    let emp5 = new Employee(5, "meeta", 7000, 20);
    this.employees.push(emp1);
    this.employees.push(emp2);
    this.employees.push(emp3);
    this.employees.push(emp4);
    this.employees.push(emp5);
  }

  ngOnInit() {
  }

  logout() {
    sessionStorage.removeItem("empId");
    this.router.navigate(["login"]);
  }

  fname: string = "Pushkar";
  lname: string = "CHAUHAN";
  salary: number = 25000;
  emp = new Employee(100, "Pushkar", 12000, 35);
  dateOfJoining = new Date();

  query:string;


}
