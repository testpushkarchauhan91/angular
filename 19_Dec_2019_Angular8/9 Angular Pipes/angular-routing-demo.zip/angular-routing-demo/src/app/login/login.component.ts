import { Component, OnInit } from '@angular/core';
import { EmployeeService }from '../employee.service';
import { Router }from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  msg: string;
  constructor(private es: EmployeeService, private router: Router) { }

  ngOnInit() {
  }

  checkUser(empId) {
    // For testing use url http://dummy.restapiexample.com/api/v1/employees
    // this.es.checkUser(empId).subscribe(result=>console.log(result));
    
    this.es.checkUser(empId).subscribe(result=> {
      sessionStorage.setItem("empId", result.id);// saving session id from the request in sessionStorage
      this.router.navigate(["home"]);
    }, error=> this.msg = "Invalid Id");

  }

}
