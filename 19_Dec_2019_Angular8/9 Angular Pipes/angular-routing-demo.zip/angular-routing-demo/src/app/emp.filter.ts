import { PipeTransform } from '@angular/core';
import { Pipe } from '@angular/core';

@Pipe({
	name:"EmpPipeInfo"
})
export class EmpPipe implements PipeTransform{
	transform(stdName:any[],
		value:string,
		label:string):any[]{
		//	console.log("Name: " + stdName);
		//	console.log("Value: " + value);
		//	console.log("Label: " + label);
		if(!label) return stdName;
		return stdName.filter(e=>e[value].indexOf(label)>0);
	}
}