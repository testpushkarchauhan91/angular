import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'component-communication';
  name: string = "Ajay Kumar"; // Declaring a variable in parent and using it in component
  
  /* Only one String :  static*/
  // stdName: string; // Using Dynamic Values generating by Parent and child will use it to display
  
  /* Multiple Names :  dynamic*/
  stdName: Array<string> = new Array();
  
  addNames(stdName: string) {
    // this.stdName = stdName; // single value
    this.stdName.push(stdName);
  }
}
