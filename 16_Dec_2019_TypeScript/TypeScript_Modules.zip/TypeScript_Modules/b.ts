export function dis2() {
	console.log("dis2() function of b.ts file");
}
export function display(){
	console.log("display() function in b.ts file");
}