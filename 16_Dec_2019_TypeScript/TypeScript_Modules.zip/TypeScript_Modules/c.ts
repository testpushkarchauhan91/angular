export function display1(){
	console.log("display1() function");
}
export function display2(){
	console.log("display2() function");
}
export function display3(){
	console.log("display3() function");
}
export let a = 10;

export class Employee{
	dis():void{
		console.log("Employee dis() function");
	}
}