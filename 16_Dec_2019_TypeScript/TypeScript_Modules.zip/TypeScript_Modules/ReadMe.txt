1. you need to use export inorder to export to other file
2. in main.ts we are importing both the functions
3.

C:\Users\training\Visual_Studio_Code_Workspace\TypeScript_Modules>tsc --init
message TS6071: Successfully created a tsconfig.json file.

C:\Users\training\Visual_Studio_Code_Workspace\TypeScript_Modules>tsc

C:\Users\training\Visual_Studio_Code_Workspace\TypeScript_Modules>node main.js
dis1() function of a.ts file
dis2() function of b.ts file

C:\Users\training\Visual_Studio_Code_Workspace\TypeScript_Modules>


4. 
same function name in 2 diff files


C:\Users\training\Visual_Studio_Code_Workspace\TypeScript_Modules>tsc

C:\Users\training\Visual_Studio_Code_Workspace\TypeScript_Modules>node main.js
dis1() function of a.ts file
dis2() function of b.ts file
display() function in b.ts file
display() function in a.ts file

C:\Users\training\Visual_Studio_Code_Workspace\TypeScript_Modules>


5. c.ts contains classes and variables

