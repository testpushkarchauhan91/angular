"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function display1() {
    console.log("display1() function");
}
exports.display1 = display1;
function display2() {
    console.log("display2() function");
}
exports.display2 = display2;
function display3() {
    console.log("display3() function");
}
exports.display3 = display3;
exports.a = 10;
var Employee = /** @class */ (function () {
    function Employee() {
    }
    Employee.prototype.dis = function () {
        console.log("Employee dis() function");
    };
    return Employee;
}());
exports.Employee = Employee;
