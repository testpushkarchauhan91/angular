"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function dis2() {
    console.log("dis2() function of b.ts file");
}
exports.dis2 = dis2;
function display() {
    console.log("display() function in b.ts file");
}
exports.display = display;
