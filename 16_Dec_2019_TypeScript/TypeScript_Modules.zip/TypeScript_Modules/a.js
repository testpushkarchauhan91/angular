"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function dis1() {
    console.log("dis1() function of a.ts file");
}
exports.dis1 = dis1;
function display() {
    console.log("display() function in a.ts file");
}
exports.display = display;
