export function dis1() {
	console.log("dis1() function of a.ts file");
}
export function display(){
	console.log("display() function in a.ts file");
}