var a=10;
var b=30;
var sum = a+b;
console.log("sum:" + sum);
console.log("Welcome to External JavaScript");