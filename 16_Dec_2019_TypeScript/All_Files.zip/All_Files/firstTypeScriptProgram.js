console.log("Welcome to type Script. Save this file with .ts");
