var a = 10;
var fname = "Ravi";
var result = true;
console.log(a);
console.log(fname);
console.log(result);
var x = 100;
x = 20;
console.log(a);
