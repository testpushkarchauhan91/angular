class Bike{
	speed():void{
		console.log("60km/hr");
	}
}
class Pulsar extends Bike{
    speed():void{
		console.log("90km/hr");
	}
	color():void{
		console.log("Black");
	}
}
let pu = new Pulsar();
pu.color();
pu.speed();