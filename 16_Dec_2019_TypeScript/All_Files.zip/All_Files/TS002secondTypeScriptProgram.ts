var a = 10;
let a = 20;
let b = 20;
let b = 40;