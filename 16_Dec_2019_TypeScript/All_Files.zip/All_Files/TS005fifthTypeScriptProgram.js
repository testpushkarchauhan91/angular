"use strict";
let a = 10;
let fname = "Ravi";
let result = true;
console.log(a);
console.log(fname);
console.log(result);
a = "Ravi";
