//var a = 10;
//let a = 20;
//let b = 20;
//let b = 40;
for (var i = 0; i <= 100; i++) { }
console.log(i);
for (var j = 0; j <= 100; j++) { }
console.log(j);
var c = 100;
c = 200;
