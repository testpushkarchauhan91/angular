class Employee { 
    constructor(private _empId: number,
        private _fName: string,
        private _salary: number) { }

    set empId(empId: number){ 
            this._empId = empId;
    }

    get empId(): number { 
        return this._empId;
    }

    set fName(fName: string) { 
            this._fName = fName;
    }

    get fName(): string { 
        return this._fName;
    }
    set salary(empSalary: number){ 
            this._salary = empSalary;
    }

    get salary(): number { 
        return this._salary;
    }
    
}

let emp1 = new Employee(100, "Ravi", 12000);
emp1.empId = 200;
emp1.salary = 1000;
emp1.fName = "Amit";
console.log(emp1.empId);
console.log(emp1.fName);
console.log(emp1.salary);