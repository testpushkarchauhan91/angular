var a = 10;
var a = 20;
var b = 20;
var b = 40;
