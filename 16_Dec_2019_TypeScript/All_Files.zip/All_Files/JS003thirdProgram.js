var a=10;
a=30;
console.log(a);
// var b=20;
//var sum = a+b;
//console.log("sum:" + sum);
console.log("Welcome to External JavaScript");