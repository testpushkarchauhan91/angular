function show(){
	console.log("Hello");
}
show();
