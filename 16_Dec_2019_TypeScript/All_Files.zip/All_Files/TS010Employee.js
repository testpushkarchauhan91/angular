var Employee = /** @class */ (function () {
    function Employee(_empId, _fName, _salary) {
        this._empId = _empId;
        this._fName = _fName;
        this._salary = _salary;
    }
    Object.defineProperty(Employee.prototype, "empId", {
        get: function () {
            return this._empId;
        },
        set: function (empId) {
            this._empId = empId;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Employee.prototype, "fName", {
        get: function () {
            return this._fName;
        },
        set: function (fName) {
            this._fName = fName;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Employee.prototype, "salary", {
        get: function () {
            return this._salary;
        },
        set: function (empSalary) {
            this._salary = empSalary;
        },
        enumerable: true,
        configurable: true
    });
    return Employee;
}());
var emp1 = new Employee(100, "Ravi", 12000);
emp1.empId = 200;
emp1.salary = 1000;
emp1.fName = "Amit";
console.log(emp1.empId);
console.log(emp1.fName);
console.log(emp1.salary);
