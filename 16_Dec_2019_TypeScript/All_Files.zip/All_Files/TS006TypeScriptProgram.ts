let a:number=10;
let fname:string="Ravi";
let result:boolean=true;
console.log(a);
console.log(fname);
console.log(result);
var x = 100;
x = 20;
console.log(a);