function Person(){
	this.pid = 100;
	this.pname = "Ravi";
	this.disInfo=funcion(){
		console.log("PID:" + this.pid + "PName" + this.pname);
	}
}

Person();
let p1 = new Person();
p1.disInfo();