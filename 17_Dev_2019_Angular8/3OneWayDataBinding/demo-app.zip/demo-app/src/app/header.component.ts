import {Component} from '@angular/core';

@Component({
	selector: 'header-tag',
	templateUrl: "./header.component.html"
})
export class HeaderComponent{
	msg:string = "Header Tag";
}
