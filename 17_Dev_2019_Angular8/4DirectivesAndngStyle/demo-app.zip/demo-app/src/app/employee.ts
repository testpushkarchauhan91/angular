export class Employee {
	constructor(public empId: number,
		public empName: string,
		public empSalary: number,
		public empAge: number) { }
}