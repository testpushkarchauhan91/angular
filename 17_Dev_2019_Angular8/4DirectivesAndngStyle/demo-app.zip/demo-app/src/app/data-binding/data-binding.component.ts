import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-data-binding',
  templateUrl: './data-binding.component.html',
  styleUrls: ['./data-binding.component.css']
})
export class DataBindingComponent implements OnInit {
  fname: string = "Ravi";
  designation: string = "Tester";
  flag: boolean = false;
  age: number = 21;
  salary: number = 16000;
  num1: number = 0;
  num2: number = 0;
  sumResult: number = 0;
  subResult: number = 0;
  sumRefResult: number = 0;
  subRefResult: number = 0;
  constructor() {

  }

  ngOnInit() {
  }

  /*Event Binding : Based on some event we are changing the propert value */
  fun() {
    this.age = 34;
  }
  sum() {
    this.sumResult = this.num1 + this.num2;
  }
  sumRef(num1,num2) {
    this.sumRefResult = eval(num1) + eval(num2);
  }
  sub() {
    this.subResult = this.num1 - this.num2;
  }
  subRef(num1: number, num2: number) {
    this.subRefResult = eval(num1) - eval(num2);
  }

}
/*
To find difference between String Interpolation and 
Property Binding use flag
in case of String Interpolation it considers its as string
in case of Property Binding it takes boolean value
 */