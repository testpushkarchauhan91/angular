node_modules is deleted.
Recreate it to run the project in VSC

C:\Users\training\Visual_Studio_Code_Workspace\AngularDemo\demo-app>ng g c main
CREATE src/app/main/main.component.html (19 bytes)
CREATE src/app/main/main.component.spec.ts (614 bytes)
CREATE src/app/main/main.component.ts (261 bytes)
CREATE src/app/main/main.component.css (0 bytes)
UPDATE src/app/app.module.ts (617 bytes)

C:\Users\training\Visual_Studio_Code_Workspace\AngularDemo\demo-app>ng g c data-binding
CREATE src/app/data-binding/data-binding.component.html (27 bytes)
CREATE src/app/data-binding/data-binding.component.spec.ts (664 bytes)
CREATE src/app/data-binding/data-binding.component.ts (292 bytes)
CREATE src/app/data-binding/data-binding.component.css (0 bytes)
UPDATE src/app/app.module.ts (821 bytes)

C:\Users\training\Visual_Studio_Code_Workspace\AngularDemo\demo-app>ng g c directive-demo
CREATE src/app/directive-demo/directive-demo.component.html (29 bytes)
CREATE src/app/directive-demo/directive-demo.component.spec.ts (678 bytes)
CREATE src/app/directive-demo/directive-demo.component.ts (300 bytes)
CREATE src/app/directive-demo/directive-demo.component.css (0 bytes)
UPDATE src/app/app.module.ts (896 bytes)