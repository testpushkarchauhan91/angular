import {Component} from '@angular/core';

@Component({
	selector: 'header-info',
	templateUrl: "./header.component.html"
})
export class HeaderComponent{
	msg:string = "Header Info";
}
