import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'demo-app';
  id:number=36074;
  name:string="Pushkar";
  salary:number=20000;
  
  display():string{
    return "Welcome to Angular 8 " + this.name;
  }
}
