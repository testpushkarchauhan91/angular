import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-templatedrivenform',
  templateUrl: './templatedrivenform.component.html',
  styleUrls: ['./templatedrivenform.component.css']
})
export class TemplatedrivenformComponent implements OnInit {
  msg: string;
  constructor() { }

  ngOnInit() {
  }

  checkUser(loginRef) {

    console.log(loginRef);
    if (loginRef.user == "admin" && loginRef.pass == "123") {
      this.msg = "Admin Successfully Logged in...";
    } else {
      this.msg = "Failure Try Once Again...";
    }

  }
}
