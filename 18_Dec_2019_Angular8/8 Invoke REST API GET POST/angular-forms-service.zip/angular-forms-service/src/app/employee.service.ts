export class EmployeeService {
	display(): string {
		return "Welcome to Angular 8 Service Using new Keyword";
	}
}