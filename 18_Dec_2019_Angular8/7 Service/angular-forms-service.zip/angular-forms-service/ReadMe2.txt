View --> Component --> Service(uses HTTPClient) --> REST API
Create a model in front end side to store the json data
create a model to store records on UI Side