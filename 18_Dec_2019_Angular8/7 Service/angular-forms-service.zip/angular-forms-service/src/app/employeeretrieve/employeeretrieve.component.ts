import { Component, OnInit } from '@angular/core';
import { FakeService } from '../fake-service';
import { Fake } from '../fake';

@Component({
  selector: 'app-employeeretrieve',
  templateUrl: './employeeretrieve.component.html',
  styleUrls: ['./employeeretrieve.component.css']
})
export class EmployeeretrieveComponent implements OnInit {
  fakeInfo: Array<Fake>;
  flag: boolean = false;
  count: number;

  constructor(private fakeservice: FakeService) {

  }

  ngOnInit() {
    //If you want to pre populate records use init
    
    this.flag = true;
    this.fakeservice.loadEmployeeInfoLoadingDataOnComponentSide().subscribe(
      data=> {
        this.fakeInfo = data;
        this.count = this.fakeInfo.length;
      });
    
  }

  loadDataOnConsole() {
    this.fakeservice.loadEmployeeInfoDisplayRecordInConsole();
  }

  loadDataOnView() {
    // If you want to display data on button click
    /*
    this.flag = true;
    this.fakeservice.loadEmployeeInfoLoadingDataOnComponentSide().subscribe(
      data=> {
        this.fakeInfo = data;
        this.count = this.fakeInfo.length;
      });
    */  
  }

  fakeRef: Fake;
  errorMessage: string;
  checkById(empId: number) {
    this.fakeservice.checkById(empId).
      subscribe(data=> this.fakeRef = data,
        error=> this.errorMessage = "Record Not Found");
  }
}
