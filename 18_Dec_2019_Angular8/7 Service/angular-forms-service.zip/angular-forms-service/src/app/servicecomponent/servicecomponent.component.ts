import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { FakeService } from '../fake-service';

@Component({
  selector: 'app-servicecomponent',
  templateUrl: './servicecomponent.component.html',
  styleUrls: ['./servicecomponent.component.css']
})
export class ServicecomponentComponent implements OnInit {
  msg: string;
  constructor(private fakeService: FakeService) {
    // Using Constructor based DI
  }

  ngOnInit() {
  }

  callService() {
    let employeeService = new EmployeeService();
    this.msg = employeeService.display();
  }

  callFakeService() {
    this.msg1 = this.fakeService.display();
  }
}
