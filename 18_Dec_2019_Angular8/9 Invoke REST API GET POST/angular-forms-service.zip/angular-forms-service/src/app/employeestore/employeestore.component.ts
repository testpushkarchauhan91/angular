import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { FakeService } from '../fake-service';
import { Fake } from '../fake';

@Component({
  selector: 'app-employeestore',
  templateUrl: './employeestore.component.html',
  styleUrls: ['./employeestore.component.css']
})
export class EmployeestoreComponent implements OnInit {

  empRef = new FormGroup({
    name: new FormControl(),
    salary: new FormControl(),
    age: new FormControl()
  });
  constructor(private fakeService: FakeService) { }

  ngOnInit() {
  }
  
  
  storeEmpInfo() {
    // Verify Info in console
    //  console.log(this.empRef.value);
    this.fakeService.storeEmpInfo(this.empRef.value);
  }


}
