import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeestoreComponent } from './employeestore.component';

describe('EmployeestoreComponent', () => {
  let component: EmployeestoreComponent;
  let fixture: ComponentFixture<EmployeestoreComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployeestoreComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeestoreComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
