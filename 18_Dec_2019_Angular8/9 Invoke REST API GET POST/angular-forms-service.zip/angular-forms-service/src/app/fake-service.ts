import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Fake } from '../fake';

@Injectable()
export class FakeService {

	constructor(private http: HttpClient) {
		// Using Constructor based DI
	}

	display(): string {
		return "Welcome to Angular 8 Service Using DI";
	}
	
	// Service must return some values
	// Service always interacts with Component
	/* 1. Displaying Records in console */

	loadEmployeeInfoDisplayRecordInConsole(): void {
		// observable design pattern
		// subscribe method will take 3 parameters which are called asynhronous call back methods
		// Old way : Promise used to load. Promise is non cancellable you have to load  
		// New way : Using subscribe
		//1 parameter : to load data one by one
		//2 if any error generated then it will be called
		//3 if no error this parameter will be invoked
		// all 3 are asynchronous call back functions
		this.http.get("http://dummy.restapiexample.com/api/v1/employees").subscribe(
			data  => console.log(data),
			error => console.log(error),
			() => console.log("completed")
			);
	}
	
	
	/* 2. Returning Data from service to component*/
	loadEmployeeInfoLoadingDataOnComponentSide(): Observable<Fake[]> {
		return this.http.get<Fake[]>("http://dummy.restapiexample.com/api/v1/employees");
	}
	
	/*3 . Check By ID*/
	// http://dummy.restapiexample.com/
	checkById(empId: number): Observable<any> {
		return this.http.get<Fake[]>("http://dummy.restapiexample.com/api/v1/employee/" + empId);
	}

	storeEmpInfo(empRef) {
		// 1 parameter is url 2 parameter is object
		this.http
			.post("http://dummy.restapiexample.com/api/v1/create", empRef)
			.subscribe(data=>console.log(data));
	}
}
/*
1. To make this class as a service class use annotation @Injectable()
 */
 
 // View --> Component --> Service --> Rest API
 // Service --> Console Print