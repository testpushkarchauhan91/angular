import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import {Validators} from '@angular/forms';

@Component({
  selector: 'app-modeldrivenform',
  templateUrl: './modeldrivenform.component.html',
  styleUrls: ['./modeldrivenform.component.css']
})
export class ModeldrivenformComponent implements OnInit {
  loginRef = new FormGroup({
    userName: new FormControl('', [Validators.required]),
    pass: new FormControl('', [Validators.required]),
    gender:new FormControl()
  });
  constructor() { }

  ngOnInit() {
  }
  
  // 1. Using Template Driven Approach
  /*
  checkUser(loginRef) {
    console.log(loginRef);
    if (loginRef.user == "admin" && loginRef.pass == "123") {
      this.msg = "Admin Successfully Logged in...";
    } else {
      this.msg = "Failure Try Once Again...";
    }
  }
  */
  
  // 2. Using Model Driven Approach
  checkUser() {
    // 1. Display all values  
      console.log(this.loginRef.value);
    // 2. Retrieve Individual Value
    //console.log("Username: " + this.loginRef.get("userName").value);
    //console.log("Password: " + this.loginRef.get("pass").value);
  }

}
