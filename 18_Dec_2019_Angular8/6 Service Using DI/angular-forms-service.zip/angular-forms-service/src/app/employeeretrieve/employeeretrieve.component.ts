import { Component, OnInit } from '@angular/core';
import { FakeService } from '../fake-service';
@Component({
  selector: 'app-employeeretrieve',
  templateUrl: './employeeretrieve.component.html',
  styleUrls: ['./employeeretrieve.component.css']
})
export class EmployeeretrieveComponent implements OnInit {

  constructor(private fakeservice:FakeService) { }

  ngOnInit() {
  }
  
  loadData() {
      this.fakeservice.loadEmployeeInfo();
  }
}
