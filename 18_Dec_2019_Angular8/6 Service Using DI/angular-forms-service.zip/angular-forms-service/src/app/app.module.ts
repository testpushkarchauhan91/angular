import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TemplatedrivenformComponent } from './templatedrivenform/templatedrivenform.component';
import { ModeldrivenformComponent } from './modeldrivenform/modeldrivenform.component';
import { ServicecomponentComponent } from './servicecomponent/servicecomponent.component';
import { FakeService } from './fake-service';
import { HttpClientModule } from '@angular/common/http';
import { EmployeeretrieveComponent } from './employeeretrieve/employeeretrieve.component';

@NgModule({
  declarations: [
    AppComponent,
    TemplatedrivenformComponent,
    ModeldrivenformComponent,
    ServicecomponentComponent,
    EmployeeretrieveComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [FakeService],
  bootstrap: [AppComponent]
})
export class AppModule { }
