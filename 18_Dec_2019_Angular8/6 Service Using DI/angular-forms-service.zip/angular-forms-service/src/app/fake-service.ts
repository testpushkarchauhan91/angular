import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class FakeService {

	constructor(private http: HttpClient) {
		// Using Constructor based DI
	}

	display(): string {
		return "Welcome to Angular 8 Service Using DI";
	}
	
	// Service must return some values
	// Service always interacts with Component
	loadEmployeeInfo(): void {
		// observable design pattern
		// subscribe method will take 3 parameters which are called asynhronous call back methods
		// Old way : Promise used to load. Promise is non cancellable you have to load  
		// New way : Using subscribe
		//1 parameter : to load data one by one
		//2 if any error generated then it will be called
		//3 if no error this parameter will be invoked
		// all 3 are asynchronous call back functions
		this.http.get("http://dummy.restapiexample.com/api/v1/employees").subscribe(
			data  => console.log(data),
			error => console.log(error),
			() => console.log("completed")
			);
	}
}
/*
1. To make this class as a service class use annotation @Injectable()
 */