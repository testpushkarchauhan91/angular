import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TemplatedrivenformComponent } from './templatedrivenform/templatedrivenform.component';
import { ModeldrivenformComponent } from './modeldrivenform/modeldrivenform.component';
import { ServicecomponentComponent } from './servicecomponent/servicecomponent.component';

@NgModule({
  declarations: [
    AppComponent,
    TemplatedrivenformComponent,
    ModeldrivenformComponent,
    ServicecomponentComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
