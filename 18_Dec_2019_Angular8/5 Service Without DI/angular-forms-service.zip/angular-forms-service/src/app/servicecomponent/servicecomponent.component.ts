import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-servicecomponent',
  templateUrl: './servicecomponent.component.html',
  styleUrls: ['./servicecomponent.component.css']
})
export class ServicecomponentComponent implements OnInit {
  msg:string;
  constructor() { }

  ngOnInit() {
  }

callService(){
  let employeeService = new EmployeeService();
  this.msg = employeeService.display();
}
}
