import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modeldrivenform',
  templateUrl: './modeldrivenform.component.html',
  styleUrls: ['./modeldrivenform.component.css']
})
export class ModeldrivenformComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
