import {Component} from '@angular/core';

@Component({
	selector: "footer-tag",
	template: 
	`
	<b>2019-20 &copy;{{msg}}</b>
	`,
	styles:["b{color:red}"]
})
export class FooterComponent{
	msg:string = "by Abc Company";
}
