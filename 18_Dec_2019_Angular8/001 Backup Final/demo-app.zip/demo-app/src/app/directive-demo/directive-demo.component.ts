import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';

@Component({
  selector: 'app-directive-demo',
  templateUrl: './directive-demo.component.html',
  styleUrls: ['./directive-demo.component.css']
})
export class DirectiveDemoComponent implements OnInit {

  flag: boolean = false;
  btn: string = "show";
  stdInfo: string[] = ["A", "B", "C", "D", "E"];
  colors: string[] = ["Pink", "Black", "Red", "Green", "White"];
  styleRules: any = { 'color': 'blue', 'font-size': '24pt' }
  // Generic Way for Array Declaration
  employees: Array<Employee>;
  // Normal Way  for Array Declaration
  // employee:Employee[];
  
  constructor() {
    this.employees = new Array();
    // this.employees = new Employee[10];
    let emp1 = new Employee(1, "A", 12000, 23);
    let emp2 = new Employee(2, "B", 17000, 24);
    let emp3 = new Employee(3, "C", 18000, 25);
    let emp4 = new Employee(4, "D", 22000, 27);
    let emp5 = new Employee(5, "E", 19000, 30);
    this.employees.push(emp1);
    this.employees.push(emp2);
    this.employees.push(emp3);
    this.employees.push(emp4);
    this.employees.push(emp5);
  }

  ngOnInit() {
  }

  changeValue() {
    if (this.btn == "show") {
      this.btn = "hide"
      this.flag = true;
    } else {
      this.btn = "show"
      this.flag = false;
    }
  }
}
