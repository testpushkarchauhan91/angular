import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }


  title = 'demo-app';
  id: number = 36074;
  name: string = "Pushkar";
  salary: number = 20000;

  display(): string {
    return "Welcome to Angular 8 " + this.name;
  }
}
