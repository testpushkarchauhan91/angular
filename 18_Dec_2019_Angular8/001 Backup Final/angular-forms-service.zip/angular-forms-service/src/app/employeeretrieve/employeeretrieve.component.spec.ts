import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeretrieveComponent } from './employeeretrieve.component';

describe('EmployeeretrieveComponent', () => {
  let component: EmployeeretrieveComponent;
  let fixture: ComponentFixture<EmployeeretrieveComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployeeretrieveComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeretrieveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
