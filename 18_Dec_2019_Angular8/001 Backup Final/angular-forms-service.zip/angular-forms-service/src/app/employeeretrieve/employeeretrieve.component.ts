import { Component, OnInit } from '@angular/core';
import { FakeService } from '../fake-service';
import { Fake } from '../fake';

@Component({
  selector: 'app-employeeretrieve',
  templateUrl: './employeeretrieve.component.html',
  styleUrls: ['./employeeretrieve.component.css']
})
export class EmployeeretrieveComponent implements OnInit {
  fakeInfo: Array<Fake>;
  flag: boolean = false;
  count: number;

  constructor(private fakeService: FakeService) {

  }

  ngOnInit() {
    //If you want to pre populate records use init
    
    this.flag = true;
    this.fakeService.loadEmployeeInfoLoadingDataOnComponentSide().subscribe(
      data=> {
        this.fakeInfo = data;
        this.count = this.fakeInfo.length;
      });

  }

  loadDataOnConsole() {
    this.fakeService.loadEmployeeInfoDisplayRecordInConsole();
  }

  loadDataOnView() {
    // If you want to display data on button click
    /*
    this.flag = true;
    this.fakeService.loadEmployeeInfoLoadingDataOnComponentSide().subscribe(
      data=> {
        this.fakeInfo = data;
        this.count = this.fakeInfo.length;
      });
    */
  }

  fakeRef: Fake;
  errorMessage: string;
  checkById(empId: number) {
    this.fakeService.checkById(empId).
      subscribe(data=> { this.fakeRef = data; this.errorMessage = ""; },
        error=> this.errorMessage = "Record Not Found");
  }
}
